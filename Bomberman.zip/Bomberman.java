import java.util.ArrayList;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Bomberman extends BasicGame {

	Grille grille;
	Personnage p;
	ArrayList<Bombe> b = new ArrayList<Bombe>();
	
	public Bomberman(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void render(GameContainer gc, Graphics g) throws SlickException {
		grille.dessiner(g);
		
		for(int i=0;i<b.size();i++) {
			b.get(i).dessiner(g);
		}
		
		p.dessiner(g);
	}

	@Override
	public void init(GameContainer gc) throws SlickException {
		grille = new Grille();
		p = new Personnage(1,1);
	}

	@Override
	public void update(GameContainer gc, int delta) throws SlickException {
		Input input = gc.getInput();
		
		if(input.isKeyPressed(Input.KEY_LEFT))
			p.gauche(grille);
		if(input.isKeyPressed(Input.KEY_RIGHT))
			p.droite(grille);
		if(input.isKeyPressed(Input.KEY_UP))
			p.haut(grille);
		if(input.isKeyPressed(Input.KEY_DOWN))
			p.bas(grille);
		if(input.isKeyPressed(Input.KEY_SPACE)) {
			if(b.size()<=1)
				b.add(new Bombe(p.getX(),p.getY()));
		}
			
		for(int i=0;i<b.size();i++) {
			if(b.get(i).doitExploser(delta)) {
				b.get(i).exploser(grille); // Supprimer les obstacles adjacents destructibles
				if(b.get(i).exploser(p)) {
					gc.exit(); // Quitte l'application
				}
				
				b.remove(i);
				i--;
			}
		}
		
	}

	public static void main(String[] args) throws SlickException {
		AppGameContainer app = new AppGameContainer(new Bomberman("Bomberman"));
		app.setShowFPS(false);
		app.setDisplayMode(19*30, 13*30, false);
		app.start();
	}

}
